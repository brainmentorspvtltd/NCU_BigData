import Mapper

word = Mapper.mapperFunction()
print(next(word))
