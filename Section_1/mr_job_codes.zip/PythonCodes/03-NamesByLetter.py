from mrjob.job import MRJob

# calculate total count of births grouped by first letter of name

class CountNames(MRJob):
    
    def mapper(self, key, record):
        split = record.split(",")
        yield split[0][0], int(split[2])

    def reducer(self, letter, births):
        yield letter, count(births)

if __name__ == '__main__':
    CountNames.run()