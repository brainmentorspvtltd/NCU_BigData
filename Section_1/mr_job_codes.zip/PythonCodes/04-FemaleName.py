from mrjob.job import MRJob
from mrjob.step import MRStep

# find count of female birth grouped by first letter of name

class WordCount(MRJob):

    def steps(self):
        return [
            MRStep(mapper = self.mapper_get_words,
            reducer=self.reducer_count_words),
            MRStep(reducer=self.reducer_find_max_word)
        ]

    def mapper_get_words(self, _, line):
        words = line.split()
        for word in words:
            yield(word.lower(), 1)
    
    def reducer_count_words(self, word, counts):
        yield None, (sum(counts), word)

    def reducer_find_max_word(self, _, word_count_pairs):
        yield max(word_count_pairs)

if __name__ == '__main__':
    WordCount.run()

